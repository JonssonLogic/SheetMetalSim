import ansa
from ansa import constants, base

def the_function():
	
	pids = base.CollectEntities(constants.LSDYNA, None, "SECTION_SHELL", False)				# Select all pids
	
	if not pids:
		print("No parts, import geometry!")
		return
		
	blank_index = [i for i,  pid in enumerate(pids) if pid._name == "blank"]
	
	if not blank_index:
		print("No blank!")
		return
	blank_index = blank_index[0]
	
	for pid in pids:
		if pid._name == "blank":
			# Create the springback set
			blank_part = pids[blank_index]
			set_properties = {"Name": "SET_SPRINGBACK", "SID": 1}
			new_set = base.CreateEntity(constants.LSDYNA, "SET", set_properties)
			base.AddToSet(new_set, blank_part)
			continue
	
		contact_name = "".join(["Contact blank-",pid._name])	
		contact_properties = {"Name": contact_name, "TYPE": "FORMING_ONE_WAY_SURFACE_TO_SURFACE", "SSTYP": "3: Part id", "MSTYP": "3: Part id", "SSID": pids[blank_index]._id, "MSID": pid._id, "FS": 0.125, "FD": 0.125, "DC": 0.0001, "VDC": 20}
			
		new_contact = base.CreateEntity(constants.LSDYNA, "CONTACT", contact_properties)

		if new_contact:
			print(f"Successfully created contact '{new_contact._name}' using Part IDs.")
		else:
			print("Failed to create the contact.")
        	
        	
if __name__ == '__main__':
	the_function()


