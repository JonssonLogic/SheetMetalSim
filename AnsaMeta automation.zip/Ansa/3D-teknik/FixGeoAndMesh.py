import ansa
from ansa import guitk, constants,base, mesh
from os.path import expanduser


def FixGeoMesh():

    base.Topo()
    pids = base.CollectEntities(constants.LSDYNA, None, "SECTION_SHELL", False) 				# Select all pids
    base.AutoCalculateOrientation(pids, True) 													# Orient pids
    ret = base.CheckAndFixGeometry(pids, ["TRIPLE CONS", "NEEDLE FACE"], [1, 1], True, True)	# Geometry check and fix ([1,1] for two errors etc.)
    if ret != None: print("[OK] Geometry")
    else: print("[ERROR] Geometry")

    home = expanduser("~")
    mesh_path = home + "\\.BETA\\ANSA\\version_25.1.1\\3D-teknik\\mesh_feature_parameters.ansa_mpar"
    # Feature recognition
    mesh.ReadMeshParams(mesh_path)
    fh = base.FeatureHandler(pids)
    fh.recognize()
	

    qual_path = home + "\\.BETA\\ANSA\\version_25.1.1\\3D-teknik\\explicit.ansa_qual"
	# Generate mesh
    faces = base.CollectEntities(constants.LSDYNA,None,"FACE")
    mesh.Mesh(faces)
    mesh.ReadQualityCriteria(qual_path)
    mesh.Reconstruct()
    mesh.FixQuality()

    # Intersection and penetration check
    ret_val = base.CheckIntersections(True, False, False)
    if ret_val != None: print("[OK] Intersections and penetrations")
    else: print("[ERROR] Intersections and penetrations")


if __name__ == '__main__':
	FixGeoMesh()