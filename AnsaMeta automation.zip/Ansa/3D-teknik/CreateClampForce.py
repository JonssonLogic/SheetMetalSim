import ansa
from ansa import guitk
from ansa import constants
from ansa import base

def clamp_force():

	TopWindow = guitk.BCWindowCreate("Create clamping force", guitk.constants.BCOnExitDestroy)
	
	BCButtonGroup_1 = guitk.BCButtonGroupCreate(TopWindow, "Settings", guitk.constants.BCVertical)
	BCLabel_1 = guitk.BCLabelCreate(BCButtonGroup_1, "Force [N]:")
	BCLineEdit_1 = guitk.BCLineEditCreateDouble(BCButtonGroup_1, 200000.00000)
	BCSpacer_1 = guitk.BCSpacerCreate(BCButtonGroup_1)
	BCSpacer_2 = guitk.BCSpacerCreate(TopWindow)
	BCDialogButtonBox_1 = guitk.BCDialogButtonBoxCreate(TopWindow)
	
	guitk.BCWindowSetAcceptFunction(TopWindow, _ok_pressed, [BCLineEdit_1])
	
	guitk.BCShow(TopWindow)


def _ok_pressed(w, data):
	
	pids = base.CollectEntities(constants.LSDYNA, None, "SECTION_SHELL", False)
	sf = guitk.BCLineEditGetDouble(data[0])
	force_name = "Clamp force - blankholder"
	curve_name = "Clamp force curve"
	index = [i for i,  pid in enumerate(pids) if pid._name == "blankholder"][0]
	pid = pids[index]
	
	dof = "3: Fz"
	
	force_curve = base.CreateLoadCurve("DEFINE_CURVE",{"Name": curve_name})
	base.SetLoadCurveData(force_curve, ((0.0, 0.0), (0.001, 1.0), (1, 1.0)))
	
	print("Curve OK!")
	
	load_properties = {"Name": force_name, "by": "rigid", "PID": pid._id, "DOF": dof, "LCID": force_curve._id, "SF": sf}
	new_load = base.CreateEntity(constants.LSDYNA, "LOAD", load_properties)
	
	if new_load:
		print(f"Successfully created Load '{new_load._name}'.")
	else:
		print("Failed to create the Load.")
	
	return True


if __name__ == '__main__':
	clamp_force()


